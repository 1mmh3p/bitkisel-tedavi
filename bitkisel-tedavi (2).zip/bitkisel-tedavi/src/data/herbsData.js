export const herbsData = [
  {
    id: 1,
    name: "Papatya",
    scientificName: "Matricaria chamomilla",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRSRNrMxECtYZk6_Wy0sWxfhgE90y3anu3NkwZ0Suzh5mG9mTRlvsxHiSq8Sa0oDkbUs12sCwlJfq2nHJFweHl5r27X5aHSZdnZlLPp9wRS",
    description: "Papatya, yatıştırıcı ve sakinleştirici özellikleriyle bilinen bir bitkidir. Genellikle çay olarak tüketilir.",
    benefits: [
      "Stres ve anksiyeteyi azaltır",
      "Uyku kalitesini artırır",
      "Sindirim sistemini rahatlatır",
      "Cilt irritasyonlarını yatıştırır"
    ],
    uses: [
      "Çay olarak demlenerek içilebilir",
      "Cilt bakım ürünlerinde kullanılabilir",
      "Buhar banyosu olarak kullanılabilir"
    ],
    warnings: "Papatya alerjisi olanlar veya hamileler doktora danışmadan kullanmamalıdır."
  },
  {
    id: 2,
    name: "Adaçayı",
    scientificName: "Salvia officinalis",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZRNkQrplHpt8oqg19xTJVTkh8JNCSGStAxvgXmmau8eOr7zsAhrbpAKq5v_tOnKumc93ZPyocGd92NAB7Rm73WzNWgzkddb79DevhdgHY",
    description: "Adaçayı, antioksidan özellikleri ve hafızayı güçlendirici etkileriyle bilinir.",
    benefits: [
      "Hafızayı güçlendirir",
      "Boğaz ağrısını hafifletir",
      "Antioksidan özellikleri vardır",
      "Menopoz semptomlarını hafifletir"
    ],
    uses: [
      "Çay olarak tüketilebilir",
      "Gargara olarak kullanılabilir",
      "Yemeklerde baharat olarak kullanılabilir"
    ],
    warnings: "Yüksek dozlarda tüketilmemelidir. Hamileler kullanmamalıdır."
  },
  {
    id: 3,
    name: "Nane",
    scientificName: "Mentha piperita",
    image: "data:image/webp;base64,UklGRuoHAABXRUJQVlA4IN4HAACwJQCdASqgAHcAPq0qq1WmIaYmFpDAFYlAGnAyv//A82/F2708B130rhv3GdmzspmHA7OTj91savAHUMUwvwW0nPSAnthhxB2bHQemj7gtDxXua8oXFySHvGbgiwEw9yoID28H+Q8hnvrvDYrf5se0h5ASACSyL7abthvJFjIew2QAgy81Dr0t/JbbG40XLaY26BkAyPor8UV4KUx9Ws0nLDU8FqllVG4mCTx7Fxqz6y/19GrgzJg4QA7ATnfVmxvjZUUvS8d7Ac1nDRPf+MtW3sWx2GpHLxhU4jN5q/Dk3AIWWE9Mv+bM+0ACzTgK6+xRme9ENpLlafSKPBb1fAhQpXvZm+MEwYaxfY9HCr+E03fOoeHuBl4Ujie9zlRe145N8dUy0lzYNR5Sw3o1p0a/WeTsheAAAP78qAAtUr4JHmQIFV8H593/o0cp96a0KA5mXjL7g28W8hjCH6z+Y26NMfgoQNuS3hPs74H+XPiA+tOQedmFDKDsOY7+mi9zXG2VzcI5GhQ9bX1tyUTEZfuCn51PFVBXX+fS5OX4DvnCrUJ51iC5D38RAZgH6TjZo6DqBRZSb1UtCzas0dF4zwsA6s3T6sjHrYNnx6AsdN1U2rDr6wWKx3v13aaLq38TwHjWoiiL9TY6zFIJtzbpCFnsiIBqdRG3vReYwPaUD6ud0vZRnBiTwX/AOtjMtuIer1JaYbWavUlmNRBwuSq50eRZcOhtaV5fxusox6GuKleJj0MAT+Wg3cC/L4YXdj4epNCtb+xD3xaA4yoFVeN1g+9Sjf2EEIVSyBGFO/gjpnB8SQZGnlm/PuqITsXY6xQaKYUpARnEykAsobwsNyxRkKR7ZJpoOIasl7q6HUOkcyk5lCjNafVi53GQaY4d/KJMfzx1rl1G4b3PLClS7ZduNCASYG3fv7ViIbIJXg28WJT4dbmvLSAfF0+eQd2oP5uZ2xLPOs8eDjER9HY7ZCbFxXNCnjERf421XWQb9xtUC+wSdhvGkZVa8+8KGynkkauBDo7dNfwJ53Lo/ciXn30f6gnbmnJN7pS3q68DSOl8WT3pFDoVTFY2lw1wyMazBa0bDB99IFvuidXAf8S3CHs5jGcxLK5k1Z2ezdPi/C65n6LP0Gw+WLVNVQlJT+SvRH74z9UKChZhz9ltqCd4WNSzyo2CyjeP19s3SALSBGUvhFXl+QLiXp0y9NmVH/VFneRNiwujD27z3crf22dcInqm19w+FSnsLWZfmd+ePvgu+Ol7d7FYIH7sTYnuOm9gzDL7nZO1bmhqKZ1NPppYV6l+vZ29AYHTD592EBUY1pZJNsunA/s+cgzSh/y8oN7bDn2rAG0ys4rp2lJBZTWL+N9CaD8yTHZMhs9EHpqqC+BF6cpNgqSGqW2AZu2XuTLpBDadTt8g2kfwTTYkM0HhrBaf9u39gRRhKeInXdrI6bvtB8WWX1xEa1+1QvHDlyWUHy9vX6akjMpX4CYIqrk41vgvs9WeN1ZXYBAQdufRVczTS7SihzafE1rTZT7YEGWv6cx/xvPtys96PYJOHiiH8oG2Vf+ndWMayBLRx0pcam4Zc41Iy7be/cUTmAwTN3SU/uFObmvo/y+mK+pK6RF6HO6FRFalH74hWxDSdaEGpi33S4zjJpuqF5nap0fQ8mV0K8F0xhuD33KGu4fUXiZ3WJYcrQWjzKhI1w58wuJ5qRVVV6utWWabhClDHGmFHwbKgF5Xgr8kM597ksxFxrwDsknNnEG/A13dSvZDXiWv4Ytx3GhH0MlvhNIEjVW0aqqQCIsWtk5YPxrJ3xIuKbdVN9kGh9BNgO81Avm472ZKMrxWjwIOm5kgK+5rJdF08mWdNSQvGkK6vF1r64f2zZPFZR7EWt9RKo7SEzmE1tKeIFRxQ63TbgNSyl8K9BwkGuS3jhDtX9/HAkqMKIYKMTmH63h3lUVvwOODb2FLxIgoBZpsjsz4eLLUvNtI+8G7ZMQPJb3/cmP24KaypD5LI7uwwpVtnc3qSDYrCfeBOVAN7c4zG8ryoCQObATzfeuqHE/spWTsaCSgnPx4DOvZIZRqIh5ONX/98CsgozR8P6vD61QF7Qn3PUQDK6w8bpQLh4FHNND+wf/vPc1l4YcffKHUszehLA71fe6qLWmO14sOcbNtQ1DTTQlyGPcnXuRcwLUtdTCylWEnBI1zuwIfty056ts/OBBPhudP0lxUQzIqARDQtQWqlt1ChFwAVzQp16oeCS/ETFShcPTJKycEJ8nu9hZ/L2kK9Ge38K22wkAZynk1K0LdqOue5D3fmYLBz+YSE5SKf/uKTiynjjbH572Y510rvrv30oVv6DBsRgCK5Sc2sFRdJAeYSEifhK05kRYJHxxvSpT0nZWgM2O4BPNCcithBZyulJxco/7KPDsAYzC/Cgjarl3vE1yAXPlklSylNp+y8FIsFtRYN7RU8SmdFIOA7BaF2REFnuzaGzlbYMKQ31g5jFEDNW7V85aZmW/ezaQ3SezuOF+Ayay9bduGZjvbBlyOLmrqTeZxzt/eXWp8MSw9AHimWsCwgjnd/CLh5s0onMSIvLt4AhtkN+fPiOfUNlEQN8VGbrr/Rq0+HnNgO/rbVc1JPrGe8hOFXJHO2vXs5RvLAliRQ6EDmNHMXbtSvYDUlWderfpLkyLitU/4zteFlg7OJxQi/1DT3AAAAAAA",
    description: "Nane, ferahlatıcı etkileriyle bilinen ve sindirimi kolaylaştıran bir bitkidir.",
    benefits: [
      "Sindirim sistemini rahatlatır",
      "Baş ağrısını hafifletir",
      "Solunum yollarını açar",
      "Ağız kokusunu giderir"
    ],
    uses: [
      "Çay olarak tüketilebilir",
      "Yemeklerde aroma verici olarak kullanılabilir",
      "Ağız gargarası yapabilir"
    ],
    warnings: "Yüksek miktarda tüketilmesi mide rahatsızlığına neden olabilir."
  },
  {
    id: 4,
    name: "Kekik",
    scientificName: "Thymus vulgaris",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRb6GeL6XN3uq205g-wBxq6m_bd8SUAhkakYumD-D3MHIgeELbLTGTmwfbOqJe8OZ7pGRYw1bph7uVJ4NIMat9DCTjl_TL2j94w5eSHR5B0",
    description: "Kekik, antibakteriyel özellikleriyle bilinen ve bağışıklık sistemini güçlendiren bir bitkidir.",
    benefits: [
      "Antibakteriyel etkiler gösterir",
      "Solunum yolu enfeksiyonlarına iyi gelir",
      "Bağışıklığı destekler",
      "Sindirim sistemini rahatlatır"
    ],
    uses: [
      "Yemeklere baharat olarak eklenir",
      "Çay olarak demlenebilir",
      "Maske ve cilt bakımında kullanılabilir"
    ],
    warnings: "Aşırı tüketimi mide rahatsızlığına yol açabilir."
  },
  {
    id: 5,
    name: "Zerdeçal",
    scientificName: "Curcuma longa",
    image: "data:image/webp;base64,UklGRlYUAABXRUJQVlA4IEoUAADQXwCdASriAJsAPsVWo0unpKMiq9b8iPAYiWI7fjoFP95BFgi+L+Xe0ZfK/hWCe68H6Xe7LVbDbFjMbzK3F2mzO0A3dizrVkQ8V4Iv2/fpHo7scqunj7XlbDNKJXLnyiJavOL56Tv/AWOPxAC36uAaBUr3V4i/oCVm3DM7UyUcXoBK5EKgq8lhOJH+H0HXkUadjoMIm87yiwnDnt3P6HIWZXRbplZJIjk/W9iCSCfy4YHj89M8c3+C7qxFmDQN+6Z5AWHbgwrUdPz13auxrqF/OZE3rBGg1llqqwk6rnMkzPK93jCoCBOeHHfHAk6YXf/mQOt7xeDD/0tVP9aTZ7ZWcYuElMqZ3vxL5NvBj5natHATzXKom6wLiH+3CDEZfYW6locSAEYbrG0ppUbKp22zss23Tw01BfC/bldGw2BcsQ+gPmzlM+eYbpjLI8fFfd0s/kd2w9Zv7sV+IxpuRs8MRZ+BUu7yZilv7CnNk/j+rlQq/B2vANUgF38cDlnAtx7y0I/1O3HlwcNajdjOjUWClSBl2PM+6v40ww0kVWJnxM1WALs09XLU9as8JQDURJbZAUZuSm1VGJhcKejGKKBJfsf4MUBkoPBYIWONwS0ukOrMVtjWIfTNTwFyZ5dRXdjVsR0p57YiEg8GYabIto8z1S560r6hvjBOrZ2snvPuKUY4v+5okwFRGV/Qg9kdyP9iSUXz4/n8AXkopcNufbpJbBH5J9HF6+QmevjuqKf9jsfYcE1nhp6jnkmp0WFCzXVnneLqqqGqcGX9nztjfbjB21yr3DVEEnqE3L4iihJ0GTgGW+IAUm60gUH4G/VJWXFxmzBDz82RPhv2NrXcCChH+gp7P22ipFRGXgma6kMFRoV5zhvLNn8uLwe0dzIV5l+f/5a4C+tmqeTYq69raY0dQxjPiTrtU2eKwYoixdBegWFBSar9WGgh6Op8MvKVNxszraASaFrbi6Y5koBL7t+4qLqVbsVZ1KqOLGmkz0aULwLAv0DoL/zBkKNiwvsa77A9fheMw7eAAPplurnxPniMSgeVK4R34j1cpzwWQoWU8X/+Jx2kzcgia6/eVMH3pPrc7Q3YVLS0XEK8fO3h25UtaHnhiq8UJ5myOvOFDCyHJDt2lwe0tVRE6L5zzg6Aq9eW/GGGO6AgLEJSP7fci95J/f/Ef/mPIm3sa5lZLtD1kqh0j33DSQfXOMvTkmV7XWbkcJ/SRzZDMc+Cj89VypxgYwd13dxTZrIjALKjUz7ZqEdH2VLfr7dEk+wbvvmFtmohqrC12H7GFMiU8dmn5ocGfEnWxmOIH4xvzF5AtBmf8z+VybseJhlARWbWs+Mq9L2tvxbyFGUfBDSH0+xB6qmNZG2YT2974EvqMwZOtpTuO42HxSA10lzOPzSbITxy08SyuLq6mmp+DW9uPyXvHaXgwBtpBfK5hz7dt+tPEhFfTZiAlPnqlH7EBFBP4MEs+M6XUfetI59vCbarG2IgsnIuhAjQwonrvCDHsaBlgttYvBPSgD4sS4AlPPiRJLy0olDoeqHQYsC5Ro348zX7nm1yXbZSh/ro7uk/Tw0Eu6KTtogEZaE8qxztpivsag8aq8BYnAVgIf07el8uV5jMrik9M1TOHaP7GEfatXkBijrAlRE2zNtVXFJ59/5LYIxZct3nwlI3WMRaF5+BYPmHsKqN6zrMmEzLfWvzO7/WuMsAwD4sl30H4/p6OP5UbBG/MqXv8wiuFHWlAdbLBe/VHS9XXVGaSWh5RHmbVWBQM1YGgGO+2h2LGphLlJi1tuZennoMVlA/kOhDYFJVJSf3U9pka7QMldTSxRymkqk17YdpUOuVgNWs/NDtXebZvw2MdhNFFgn+f16r4FyWkwvgtcE2UWsFuuQ9j6RYLan3D+TSQI/hOXvm2RJmrsa+o+NzZBX3n5B1+rEtcOyACOepL2Przz04WafErXjMKvjVkrcC39glXbiEb/fRKX30v8JxGeGOCWtnYLNdOyIOM1wOwsFLU7GE//6ushEx2kZBCA/qc8PYvQR9MNQanwpC0FGAky0Fd0HMIdIhsTr9YAFyzE2cAabwSrAYTdZH+5IHuHYsEZMCiC5u+zuxhW5OgBjalyGVsY8405Lg60j8wzYbO6Au8V9/h8U5ta50wTPvQyoGERg8vRT+YN956RgyfjUHM8i2X6tC7NArG+0K/SCdKjPRyYQt+gEItvTjz+PUUGTU9au9vQQZXE1PrOi8knBjSJI/CTOXrDVaYc/EjVYPYAWeVKc6RcNujSoIbde1G9siXzl78oLf+9Gczl5LIlf93omy0+tXr7X9ZsNnwMxbWQfrqdXFMqYYojul8fJyQLx9tPsFw4Ypeml4Lgjk4mrRm6RRQUWN74h79aTZVKOZW0JZooS3Zi9EvkeCY0LMZ7mwEp2CdqAxsXyeuAwX2v87Y33QlzSN8MmvcaKqc/OZOp/l23Jyy8C3b29RhuOabI8AWFCJ/K8/tSNcz8tt/RSFIa8vZgOY1E+9f380EMhBxVQdAMwWUWvRstixsQxcGXRHIpYvgknthT7SJ1nk5aRG4S5+WQEf9urTheVFk3u4y2q3IaGySpCWUEKA0WVLJM+cA74MaUm/TWlN0NmoQ/vvzXAj8E38qVNudBJjiQsIUBZ0Jsy8wyafaK/6Pcff24g9sJU1sxcMoOkITe6YZGZ+g8WGo03rGZaOxC/Zr9Y+3p99dwt8O96RUJgBYemxxoixHGnbNi4zU1NFnXc+qqlsPVAl/OzWEixHOdeXai7CU241Q5JfkB0ZUyruRaWOant1QYLSH1foVzLcvNofJ4WRY+eghbFpV2GVGcGmaGcQRRFAmptMcPn/KNAC/CPf9AngvArERZo80WyaBbWvoP9O9dKZSWGnTFabCinfJjGFfMCDNnWXebXLWySbwi3CA8LdyYSL9Tv/y7KgKFhQ1QU9Pl5EjsLF0avi/T6dR132YzoSWmg3OMHji52HAUVg6ZuzMFA2T9P1EQqmj2/BjLvjVnyEUXRV5iavMoconVfVbgVq4ZT7gx7XimoY4fnBZ3Lj+xNiTfQ5wPxMJ1IKkFh9PItrqvc3NyPHO2CGH/pXSV1IcTTKazRgAfE8xCfn6tCrsm0wfTLw1IPlSZ84v0ZjF6tyoBo1ePiPsH1WWJCeEcCuOQcoZ3lOMoVPrjKErIigPXXIwJBqWBv7Bs+ruqEx5RChXUPKfIlzTIhTCFWbWcwhJEV6OVfjL0qRAejednkf8qGLJmFd613rNDCqKICH8Hn1vIwkWN9PQE4+VDDLoSHZOr1pYXpUFVp2ltUdJfYECXcKPJ70ffvCxggGV0z0Y0Du5sxXB9DiMtej2hv60RxCiWeQKij6AKE6LwfBAK2sdmzQ/l9Tqa3Q45ryAwHAtiz/jIgFi5tqTfJjDkVrnaxW9lNOVuDzLU1pGikt3VaPOkRIuSlZYGjpKuaJa/PiSP8rKFyCOBHeS1fACHVzSfe64VwHLmbCQHHM7NGNNSnXUmVFivk3Eyc15bbOV1vXTBbN9zaY3knHK+oqtB1pSIz9I2vL0qL36JWdgov8QODtzIaQvRTeb0piX0kyjH3IE34LE0iUGTO+GI7oqkMQ2BT/zDseRPcFwF+KkCbTxBx/GA1LVSr/CTEttldyi8dh62JndXE5d42jSbFQZMNkCNmy/Y84TZs5IggXfptHPS4U7V/8F4pdTKkJLibVCQR5hqgJnU3JqAxBnRz04RWloZOUK4k4KuhEvxVehL5G/6AR20+VcrPmNlmOV646Te19GCnEiCNzi7WOSSCKnkUGdWWBRraHuB634Fx9eTo4W5C199r7DDzCnfWW18Vq7H1voYezZy46t/8W3LfO4ZkC663jPDgn1Su1gBR38MhrXMcEhGGrnOJvbbta5Xm9SUDr/4nvxVqY24UFfssxiFF8mHxhxw6+6rYQMNwn7DwQHPRS/VX/ZCU8KhCGgDIbPanJMIlipJGa5LxcO3ko8n6IS+ijsBBBGvu+4m70MJZr+SPWQUJK8qV1Nc5v5boDt4/L47M7DLZnPDub/qgfbqqOAXaAC/nteKx2IPR6aQ9G8w+nFycQXz5muQe5vZHhCgdXqugcFnjFJ9zzoUmjoEPp/1oWjJWdr6cMrHWlLDEPrA6oPjaxU5Z7IEglEkW70BwzJQcGrFylDNnEhFJZ0V4jWwLZtIadHSNEMFEw8lFgMtFjSdNUU/B+EqEW6tk2q8a/7jNsESz7ANduNp+xPU45FYRwFDfE2Qqi1YQUeoEqHHHYVpdC729JV4/9IrQUmlfo82wZ9w9HvcUFWOk4q0NxrwjKvnC0PKXtwatZslC7Ks5t7RdiKcHFgBxlug7gaEh4Q5jYe4eKNVD9rkXTaf5YKlhZsnfuvoeSHnDbL/THjb3nykVZTS5FVs4OFARWo7re+Bvwz8bsPV+T0K+6qDwNmsFIoqx0M7VsFBB8SLpkkL6bkSfGZLuStbzHxzeXOSd5MZsZb20lEWNAEp8W+o+/AXXu/wkaXGnf6FPU1xXRZDc2YBDctzz8cMAU+Qgur9VjmAI1lnmgGyKFm/l8xbeT+9yYfcEkamP9/ILTJyYdnVruLpAw8I5UjlC4RUaoX/sZMr0uz8sPd5omHC9J6bjEEohKbM/VGUWMixIQ/e6jjL/4wsld72KPIckT6C0n0dKgqmRQ3i59Uoy3Lyf7c++h4D2Eg+3StjLpH4G+YYUuQgFk9KN5MnWTt3N4zlRPgsGqd06XtPedQ2AT/76aiAv23zUEHOLXDJYytZ8LiY1dw/r892091MGnA9o8VdqSnXH0nOm0ahtXVpHGHSVdy417LSwFSh3dF8ESXTdzvMU0OkBv1kK4+zAugx6umGlmvL9X4O6IZ4sklQFnAfN/A9vsNBYTovpfU60erLyOoyG5E9fh0dW2GtN+okTpfhhvryux9JTY45E6xlM9w37oBfmCM8gFSL3nwsOYMmews8uhTr0BbWqYyGN1fZSxdG9kxRUyF4Io51Ns7gu4Jjc5PP6WlKlKpJ8vcaLB+zvWgBHpejmvFmI9KzEEYFbvznDYkqp7jxkrkaGQqDTazvzuoF9pl6a1SLTScmll40SIaAeA9WLsgdVAm8Jlc2C37AbUNrE0e6qQ30OeCpzJVyQUgQ/aIO4msqM+6s+kCSbTn7o/dvN++m9I+/qrt8GzPuo2Bd2i27dh+c+EuJVIvQTc2QcX33pzdK9qkIrG990u+DujZ7kaxbwN9+y2dJ+vlXl2t2vlWP8PTQhp1Qxc/qa5T7dyuBA/X6J4gdvg7iMY8zJeaQdq9cwZ/sZddKIkSvMwxa3qkibrp+sL5obJQyTHmiU+f8OkS7Cc+xNoCqbbMAZUbvBrSp1MBNyQz50hJ+/bMQ9Esy6EjTAKiq5EPOCT0yaBg/vdQLe13k4uQDRNvKujj83U1ECw6foJDwJ5aLxwjBAPn3Y+0iec5YqwWtNAj3KJuNCMYwVFQlhc6NghslySbyOu/H8AUPYeadONldEQ0FUqzbQsg1LJduzdenXsgYi/A7KH4Nff9M1yTOy8FvmL6ENW20igU7XVmZxVjcBzQ3m1jkShcSWOJPZoGu4NWzzzYa/+jbNkOXkh1GD9yRzHBq7hLCgOBPfp2/v+1Pxc7fuXrkl25qmuV0RYjBv2C1iId7qzRA7r0LvmV4sGqfgMID+hO9aubDkbZHRtYaH8Igx79GL5Vamg2Hwo3mM3e6Eup9twwOkPo4cQ+PfOFLBk6JcFB1+wgSbC+O46pza7J+4Tb4LyuSdOTATe26XCWI4OUI846iloVOvghgn3l621Lo/7hE7G8eKU7gG6wvxTNzSO0Zuk6rql6CxVnPxfN05Q9Iis3wmlsbmjBIGpvyhXZJq3sy110kKbMRZgqqbx9gMHM1U7RLzRRgOocZzg0QoDlnImRom+V3NPqJHmwNhiIopHkCrCFekvFc4Yb90D1PYWin6/KqFKC2tYkH+cLx4ZOv6oQiYOdlkFwWTl38BsTCYrpdD7oZTmFnNWaVp5oRgRF7ozkue9jx6mTyW1No6vPHcasqaOW4yyg1mi2rgyflPxCQJ3xZjtNZjTrgY6vusIYUzVVnHW4Bbm1Obng7RVKOzt1QPqYREwCsHmagrZbMBOvLmX8WNSmheK2KCPUcuC3mtp4SghtjB4e1EB36WfpX6nMns4WiO0nwg1KJPmxu6dDvlWwCAXzzUrSLRHDaKd2/qrZPQI41P2kcJQTakbSV57D2pmFZ+NDbNku9cIjwV8GW6PgUZYqxBtdulxFhzD5BMl3pRzhokpXhxHUVlz8MFvNIA/Vt4fn74XRD1ku+zuQjh0tOGzm4ZkFahAH/xDcPd8uksnMd3aqo1lzR6cBGS4AeZscs0TO/zz1EEVbuSDknHNoJEpXQrjGMg8ikf3LkBFc0j5NJQ6nMfEBNCoQabIVW893KQtNniU52ss19MX48mlpwt6eqzDf6D5XKYoJFxNXqPrK0EB4pGAUIg2QH7c7osoOTXZ2ctmmbJCbHszVb8tzYRejZoeD0qe6Z3DTPYdh90I8kKzD+JdVyADJlmrpzm7aOYQx/DWfprIyHtJZcYoRv5kf7eKS4TN4KQ0QvEAjE9+54BeXwJbYh+V1O7NCBn9Sul4TKApX+ueUS/1k2KhfaIMbtQ/nxcfWMtiYjkIvACa7xU+GUynCY71M1q35gwF41So1fQmWa33CgyBLX11/f0oO0uq/8lW0MvbGUWAXJi8NhMLfmdex1mnzVw3fGrVp18I+Lvn98ePwh2Vwmy9bcTBhnPmffUfRE9Ve0Q9zyVgoTxBTl/OFolAvzFg4ADTsIwxsyNjCzRJFsLlAAA7EFiiq3M0pp1hDDgP6ztN7Kx3xkewvf90/5y+8/2bfgu/SObxCh/GZfxAQDg9qPjWjgIkJhWCOmeUNrGEp60FK0pOW89MAAAA",
    description: "Zerdeçal, anti-inflamatuar ve antioksidan özellikleriyle bilinen bir baharattır.",
    benefits: [
      "İltihapları azaltır",
      "Bağışıklık sistemini güçlendirir",
      "Sindirim sorunlarına iyi gelir",
      "Cilt sağlığını destekler"
    ],
    uses: [
      "Yemeklere baharat olarak eklenir",
      "Sütle karıştırılarak içilebilir",
      "Cilt bakım maskelerinde kullanılabilir"
    ],
    warnings: "Yüksek dozda kullanımı karaciğer sorunlarına neden olabilir."
  }
];