export const Colors = {
  primary: '#4CAF50',
  primaryDark: '#388E3C',
  primaryLight: '#C8E6C9',
  accent: '#FFC107',
  textPrimary: '#212121',
  textSecondary: '#757575',
  divider: '#BDBDBD',
  white: '#FFFFFF',
  background: '#FAFAFA',
  error: '#F44336',
  success: '#4CAF50',
  warning: '#FF9800',
};